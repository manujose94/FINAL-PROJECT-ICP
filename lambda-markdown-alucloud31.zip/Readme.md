# MiniFaas



- [MiniFaas](#minifaas)
  - [Contexto](#contexto)
    - [Tecnologias utilizadas](#tecnologias-utilizadas)
  - [Despligue](#despligue)
    - [Despliegue kumori](#despliegue-kumori)
  - [Componenetes](#componenetes)
    - [Frontend](#frontend)
    - [Worker](#worker)
    - [Nats](#nats)
    - [CockroachDB](#cockroachdb)
    - [Watchman](#watchman)
  - [Funcionamiento](#funcionamiento)
    - [Requests API](#requests-api)
    - [Ejemplo lanzamiento](#ejemplo-lanzamiento)
      - [](#)
      - [Peticion de lanzamiento](#peticion-de-lanzamiento)
    - [Posibles mejoras](#posibles-mejoras)
  - [Table of Contents](#table-of-contents)


## Contexto

En este proyecto se ha desarrollado un sistema que permite la ejecución dinámica de funciones por parte de usuarios, haciendo uso de la plataforma PaaS Kumori.

### Tecnologias utilizadas

La tecnología principal en la implementación del proyecto es el lenguaje de programación [NodeJS](https://nodejs.org/es/), con el que se ha creado una API REST que gestiona el acceso a las diferentes funcionalidades del sistema.

* [Dockerfile](https://docs.docker.com/engine/reference/builder/) : Mediante los ficheros Dockerfile se han configurado los contenedores necesarios para el despliegue del sistema.
* [NATS](https://nats.io/): Internamente la API hace uso del sistema de colas NATS para la comunicación entre el frontend y los nodos encargados de la ejecución de las funciones.
* [CockroachDB](https://www.cockroachlabs.com/) : Se ha utilizado como base de datos para los diferentes datos que maneja el sistema.
* [Kumori](https://kumori.systems/) : La aplicación se ha alojado en esta plataforma PaaS.

Por otra parte se han implementado una serie de shell scripts para el lanzamiento de funciones en nodejs o javascript y facilitar la configurarón de la inicialización de contenedores como NATS o CockroachDB.

## Despligue



### Despliegue kumori



## Componenetes



### Frontend

### Worker

### Nats

### CockroachDB

Se crea un container Docker de la base de datos, configurado de forma automática mediante un script en bash.  

La base de datos contiene información de:

-	Usuarios: Se almacena información de los usuarios para llevar un seguimiento.
-	Funciones: Se almacenan las diferentes funciones y sus códigos, además de otra información como el usuario que ha registrado la función.
-	Resultados: Se almacenan todos los resultados de cada ejecución.
-	Recursos: Se registra toda la información relativa al consumo de recursos de cada cliente; las funciones que ejecuta y el tiempo de ejecución.

### Watchman



## Funcionamiento



### Requests API



### Ejemplo lanzamiento

#### 

#### Peticion de lanzamiento





### Posibles mejoras
## Table of Contents

1. [Readme](/Readme)
	1. [Contexto](Readme/#contexto)
	2. [Despligue](Readme/#despligue)
	3. [Componenetes](Readme/#componenetes)
	4. [Funcionamiento](Readme/#funcionamiento)
