from __future__ import print_function
import boto3
import os
import sys
import uuid
#from weasyprint import HTML, CSS
#https://nikku1234.github.io/2020-09-27-PDF-Conversions-using-Python-Packages/
import markdown     
s3_client = boto3.client('s3')
     
def converter_doc(doc_path):
    base=os.path.basename(doc_path)
    print("Basename: {}".format(base))
    name=os.path.splitext(base)[0]
    print("Name: {}".format(name))
    path_not_format=doc_path.split(".")[0]
    print("path_not_format: {}".format(path_not_format))
    markdown.markdownFromFile(
    input=doc_path,
    output='{}.html'.format(path_not_format),
    encoding='utf8',extensions=['fenced_code', 'codehilite']
    )
    return '{}.html'.format(path_not_format), '{}.html'.format(name)

'''def makepdf(html,name):
    # Make a PDF straight from HTML in a string.
    # Make a PDF straight from HTML in a string.
    html = open(html, 'r').read()
    pdf = HTML(string=html, base_url="").write_pdf()
    dirname = os.path.dirname(__file__)
    if os.path.exists(dirname):
        f = open(os.path.join(dirname, '{}.pdf'.format(name)), 'wb+')
        f.write(pdf)'''

def handler(event, context):
    for record in event['Records']:
        bucket = record['s3']['bucket']['name']
        key = record['s3']['object']['key'] 
        operation_id=uuid.uuid4()
        download_path = '/tmp/{}{}'.format(operation_id, key)
                
        print ("Downloading markdown in bucket {} with key {}".format(bucket,key))          
        os.makedirs(os.path.dirname(download_path), exist_ok = True)
        s3_client.download_file(bucket, key, download_path)
        download_new_path, new_file=converter_doc(download_path)
        bucket_out = bucket + '-out'
        
        new_file_out='{}/{}'.format(key.split('/')[0],new_file)
        print ("Uploading html in bucket {} with key {}".format(bucket_out,new_file_out))          
        s3_client.upload_file(download_new_path, '{}'.format(bucket_out), new_file_out)
        
        print ("Changing ACLs for public-read for object in bucket {} with key {}".format(bucket_out,new_file_out))          
        s3_resource = boto3.resource('s3')
        obj = s3_resource.Object(bucket_out,new_file_out)
        obj.Acl().put(ACL='public-read')
        return {'message': "Crado {}".format(new_file), 'event': event, 'success': True, 'buket_out':bucket_out, 'key':new_file_out, 'operation_id':str(operation_id)}
	
        
if __name__ == '__main__':
  converter_doc(sys.argv[1])