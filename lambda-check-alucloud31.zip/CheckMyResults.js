"use strict";

const AWS = require("aws-sdk");
var fs = require('fs');
const UUID = require('uuid/v4');
var path = require('path');
const s3 = new AWS.S3();
const bucket = process.env.Bucket;

module.exports.handler = (event, context, callback) => {
  let requestBody = JSON.parse(event.body);
  console.log({requestBody})
  return true
   var params = {
    Bucket:Bucket_Name,
    Delimiter: '/',
    Prefix: 'foldername/'
    };
  s3.listObjects(params, function(err, data) {
    if (err) {
        return 'There was an error viewing your album: ' + err.message
    }else{
        console.log(data.Contents,"<<<all content");

        data.Contents.forEach(function(obj,index){
            console.log(obj.Key,"<<<file path")
        })
    }
})

};

/**
 * @param {*} data
 */
function uploadToS3(data, key) {
  console.log(data);
  return s3
    .putObject({
      Bucket: bucket,
      Key: key,
      Body: data,
      ContentType: imageType
    })
    .promise();
}


function uploadToS3(bucketName, keyPrefix, filePath) {
    // ex: /path/to/my-picture.png becomes my-picture.png
    var fileName = path.basename(filePath);
    var fileStream = fs.createReadStream(filePath);

    // If you want to save to "my-bucket/{prefix}/{filename}"
    //                    ex: "my-bucket/my-pictures-folder/my-picture.png"
    var keyName = path.join(keyPrefix, fileName);

    // We wrap this in a promise so that we can handle a fileStream error
    // since it can happen *before* s3 actually reads the first 'data' event
    return new Promise(function(resolve, reject) {
        fileStream.once('error', reject);
        s3.upload(
            {
                Bucket: bucketName,
                Key: keyName,
                Body: fileStream
            }
        ).promise().then(resolve, reject);
    });
}